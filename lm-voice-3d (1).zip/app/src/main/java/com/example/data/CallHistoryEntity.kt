package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "call_history")
data class CallHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val username: String,
    val phone: String,
    val lmId: String,
    val timestamp: Long = System.currentTimeMillis(),
    val durationSeconds: Int = 0,
    val isIncoming: Boolean = false,
    val wasAnswered: Boolean = true,
    val type: String = "HD Wi-Fi", // e.g., HD Wi-Fi, Twilio PSTN, Telnyx Landline
    val callCost: Double = 0.0,
    val ratePerMin: Double = 0.0,
    val countryName: String = "",
    val isPstn: Boolean = false
)

