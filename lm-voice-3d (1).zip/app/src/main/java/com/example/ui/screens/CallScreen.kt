package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ContactEntity
import com.example.ui.components.AnimatedAudioWave
import com.example.ui.components.GlassmorphicCard
import com.example.ui.theme.*
import com.example.viewmodel.AppViewModel
import com.example.viewmodel.CallState

@Composable
fun CallScreen(
    viewModel: AppViewModel,
    modifier: Modifier = Modifier
) {
    val activeState = viewModel.activeCallState
    val contact = viewModel.activeCallContact
    val duration = viewModel.callDurationSeconds

    // If there is no active call, do not show anything
    if (activeState is CallState.Idle || contact == null) {
        return
    }

    val isDark = viewModel.isDarkTheme

    // Dark cyber calling overlay or light clean overlay
    val overlayBackground = if (isDark) {
        Brush.verticalGradient(listOf(Color(0xFF070B18), Color(0xFF13152C)))
    } else {
        Brush.verticalGradient(listOf(Color(0xFFF1F2F9), Color(0xFFD4D8F3)))
    }

    // Call duration formatter (e.g., 03:22)
    val mins = duration / 60
    val secs = duration % 60
    val timeString = String.format("%02d:%02d", mins, secs)

    // Pulsing animation for calling halo glow
    val infiniteTransition = rememberInfiniteTransition(label = "pulseRing")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.3f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulseScale"
    )
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.6f,
        targetValue = 0.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulseAlpha"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(overlayBackground)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        // Glowing background nodes
        Box(
            modifier = Modifier
                .size(320.dp)
                .background(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            if (activeState is CallState.Connected) BrandAccent.copy(alpha = 0.15f) else BrandSecondary.copy(alpha = 0.15f),
                            Color.Transparent
                        )
                    )
                )
        )

        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // 1. Connection Header & Encryption Seal
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(top = 16.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (isDark) Color(0x19FFFFFF) else Color(0x194F46E5))
                        .border(
                            1.dp,
                            if (isDark) Color(0x33FFFFFF) else Color(0x334F46E5),
                            RoundedCornerShape(20.dp)
                        )
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Icon(
                        imageVector = if (viewModel.isPstnCallActive) Icons.Default.Public else Icons.Default.Lock,
                        contentDescription = "Secure Link",
                        tint = BrandAccent,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (viewModel.isPstnCallActive) "LICENSED VoIP PSTN ROUTING ACTIVE" else "END-TO-END ENCRYPTED HD AUDIO",
                        color = if (isDark) Color.White.copy(alpha = 0.7f) else Color(0xFF1E1B4B),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                }

                Spacer(modifier = Modifier.height(28.dp))

                // Call status labels
                Text(
                    text = when (activeState) {
                        is CallState.Ringing -> "SECURING VOICE PROTOCOLS..."
                        is CallState.Connected -> if (viewModel.isPstnCallActive) "OUTBOUND STIR/SHAKEN TELECOM TRUNK" else "CONNECTED - DIRECT LINK"
                        else -> "LM SECURE LINK"
                    },
                    color = BrandAccent,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = contact.username,
                    color = if (isDark) Color.White else Color(0xFF1E1B4B),
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Black,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = if (viewModel.isPstnCallActive) {
                        "Rate: $${viewModel.activeCallRatePerMin}/min • Destination: ${viewModel.activeCallCountryName}"
                    } else {
                        "ID: ${contact.lmId} • ${contact.phone}"
                    },
                    color = if (isDark) Color.White.copy(alpha = 0.5f) else Color.Gray,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            // 2. Beautiful Pulsing Core Avatar and Wave
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                // Pulse Glowing Circle rings
                if (activeState is CallState.Ringing) {
                    Box(
                        modifier = Modifier
                            .size(180.dp)
                            .border(6.dp * pulseScale, BrandAccent.copy(alpha = pulseAlpha), CircleShape)
                    )
                    Box(
                        modifier = Modifier
                            .size(140.dp)
                            .border(3.dp * (pulseScale * 1.2f), BrandSecondary.copy(alpha = pulseAlpha), CircleShape)
                    )
                }

                // Main Caller Portrait
                Box(
                    modifier = Modifier
                        .size(160.dp)
                        .clip(CircleShape)
                        .background(
                            brush = Brush.sweepGradient(
                                colors = listOf(BrandAccent, BrandSecondary, BrandPrimary, BrandAccent)
                            )
                        )
                        .padding(6.dp)
                        .clip(CircleShape)
                        .background(if (isDark) Color(0xFF0F1225) else Color.White),
                    contentAlignment = Alignment.Center
                ) {
                    // Huge Initials or icon representation
                    Text(
                        text = contact.username.split(" ").map { it.take(1) }.joinToString(""),
                        color = BrandAccent,
                        fontSize = 48.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }

            // 3. Audio Wave and Timer Display
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 32.dp)
            ) {
                if (activeState is CallState.Connected) {
                    // Wave fluctuation
                    AnimatedAudioWave(
                        active = !viewModel.isMuted,
                        maxHeight = 44.dp,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )

                    // Ticking count timer
                    Text(
                        text = timeString,
                        color = if (isDark) Color.White else Color(0xFF1E1B4B),
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp
                    )

                    if (viewModel.isPstnCallActive) {
                        val activeMinutes = Math.max(1.0, Math.ceil(duration / 60.0))
                        val currentPendingCharge = activeMinutes * viewModel.activeCallRatePerMin
                        Text(
                            text = "ESTIMATED CHARGE: $${String.format("%.3f", currentPendingCharge)} USD",
                            color = Color(0xFFFBBF24), // Gold glowing text
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                        Text(
                            text = "Level A Attest • Latency: 42ms • Packet Loss: 0.0%",
                            color = if (isDark) Color.White.copy(alpha = 0.5f) else Color.Gray,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    } else {
                        Text(
                            text = "HD WI-FI Call IN PROGRESS",
                            color = Color.Green,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                } else {
                    // SECURING HANDSHAKE STATE
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                        modifier = Modifier.padding(bottom = 16.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(BrandAccent)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (viewModel.isPstnCallActive) "${viewModel.selectedVoipProvider.uppercase()} SIP TRUNK SIGNALING..." else "ESTABLISHING SECURE PROTOCOLS...",
                            color = if (isDark) Color.White.copy(alpha = 0.6f) else Color.DarkGray,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // 4. Interactive Call Action Control Panel
            GlassmorphicCard(
                modifier = Modifier.fillMaxWidth(),
                cornerRadius = 32.dp,
                isDarkTheme = isDark
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // 4a. Mute Toggle
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable { viewModel.isMuted = !viewModel.isMuted }
                    ) {
                        Box(
                            modifier = Modifier
                                .size(54.dp)
                                .clip(CircleShape)
                                .background(
                                    if (viewModel.isMuted) BrandSecondary.copy(alpha = 0.3f)
                                    else if (isDark) Color(0x19FFFFFF) else Color(0x114F46E5)
                                )
                                .border(
                                    1.dp,
                                    if (viewModel.isMuted) BrandSecondary else Color.Transparent,
                                    CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (viewModel.isMuted) Icons.Default.MicOff else Icons.Default.Mic,
                                contentDescription = "Mute",
                                tint = if (viewModel.isMuted) BrandSecondary else if (isDark) Color.White else BrandPrimary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Mute",
                            color = if (isDark) Color.White.copy(alpha = 0.6f) else Color.Gray,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    // 4b. CRITICAL Terminate call action button (Red, 3D style)
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .background(
                                brush = Brush.verticalGradient(
                                    colors = listOf(Color(0xFFEF4444), Color(0xFFB91C1C))
                                )
                            )
                            .clickable { viewModel.endCall() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.CallEnd,
                            contentDescription = "End 3D Call",
                            tint = Color.White,
                            modifier = Modifier.size(32.dp)
                        )
                    }

                    // 4c. Speaker Toggle
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable { viewModel.isSpeakerOn = !viewModel.isSpeakerOn }
                    ) {
                        Box(
                            modifier = Modifier
                                .size(54.dp)
                                .clip(CircleShape)
                                .background(
                                    if (viewModel.isSpeakerOn) BrandAccent.copy(alpha = 0.3f)
                                    else if (isDark) Color(0x19FFFFFF) else Color(0x114F46E5)
                                )
                                .border(
                                    1.dp,
                                    if (viewModel.isSpeakerOn) BrandAccent else Color.Transparent,
                                    CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.VolumeUp,
                                contentDescription = "Speaker",
                                tint = if (viewModel.isSpeakerOn) BrandAccent else if (isDark) Color.White else BrandPrimary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Speaker",
                            color = if (isDark) Color.White.copy(alpha = 0.6f) else Color.Gray,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }
    }
}
