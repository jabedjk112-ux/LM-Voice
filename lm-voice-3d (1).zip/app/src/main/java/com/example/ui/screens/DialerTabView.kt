package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.GlassmorphicCard
import com.example.ui.components.ThreeDButton
import com.example.ui.theme.BrandAccent
import com.example.ui.theme.BrandPrimary
import com.example.ui.theme.BrandSecondary
import com.example.viewmodel.AppViewModel
import com.example.viewmodel.CountryRate
import com.example.viewmodel.CountryRatesList

@Composable
fun DialerTabView(
    viewModel: AppViewModel,
    isDark: Boolean,
    modifier: Modifier = Modifier
) {
    var dropdownExpanded by remember { mutableStateOf(false) }
    val selectedCountry = viewModel.selectedDialCountry
    val customNumber = viewModel.customDialNumber

    // Dialog & error states
    var showSpamAlert by remember { mutableStateOf(false) }

    // Synchronize state with ViewModel
    LaunchedEffect(viewModel.detectedSpamAlert) {
        showSpamAlert = viewModel.detectedSpamAlert != null
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            
            // 1. Sleek Country Selector dropdown
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "SELECT DESTINATION COUNTRY",
                    color = if (isDark) Color.White.copy(alpha = 0.5f) else Color.Gray,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                Box {
                    Button(
                        onClick = { dropdownExpanded = true },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isDark) Color(0x19FFFFFF) else Color(0xFFE2E8F0)
                        ),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                1.dp,
                                if (isDark) Color(0x33FFFFFF) else Color(0x334F46E5),
                                RoundedCornerShape(16.dp)
                            )
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = "${selectedCountry.flag}  ${selectedCountry.name} (${selectedCountry.code})",
                                color = if (isDark) Color.White else Color.Black,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Icon(
                                imageVector = Icons.Default.ArrowDropDown,
                                contentDescription = "Select Country",
                                tint = if (isDark) Color.White else Color.Black
                            )
                        }
                    }

                    DropdownMenu(
                        expanded = dropdownExpanded,
                        onDismissRequest = { dropdownExpanded = false },
                        modifier = Modifier
                            .fillMaxWidth(0.9f)
                            .background(if (isDark) Color(0xFF13152C) else Color.White)
                    ) {
                        CountryRatesList.forEach { country ->
                            DropdownMenuItem(
                                text = {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "${country.flag}  ${country.name} (${country.code})",
                                            fontWeight = FontWeight.Bold,
                                            color = if (isDark) Color.White else Color.Black
                                        )
                                        Text(
                                            text = "$${country.ratePerMin}/min",
                                            color = BrandAccent,
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 13.sp
                                        )
                                    }
                                },
                                onClick = {
                                    viewModel.selectedDialCountry = country
                                    dropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                // Call rate ribbon decoration
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(BrandAccent.copy(alpha = 0.15f))
                        .padding(horizontal = 12.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.MonetizationOn,
                        contentDescription = null,
                        tint = BrandAccent,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Outbound rate: $${selectedCountry.ratePerMin}/min • Connected via ${viewModel.selectedVoipProvider}",
                        color = BrandAccent,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 2. Dialer Screen Input Display (formatted number)
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = if (customNumber.isEmpty()) "ENTER INTERNATIONAL NUMBER" else "OUTBOUND PSTN SIGNAL",
                    color = if (isDark) Color.White.copy(alpha = 0.4f) else Color.Gray,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (customNumber.isEmpty()) selectedCountry.code else customNumber,
                        color = if (customNumber.isEmpty()) Color.Gray else (if (isDark) Color.White else Color.Black),
                        fontSize = 26.sp,
                        fontWeight = FontWeight.Black,
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                        modifier = Modifier.weight(1f)
                    )

                    if (customNumber.isNotEmpty()) {
                        IconButton(
                            onClick = {
                                if (customNumber.length > selectedCountry.code.length) {
                                    viewModel.customDialNumber = customNumber.dropLast(1)
                                } else {
                                    viewModel.customDialNumber = ""
                                }
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.Backspace,
                                contentDescription = "Backspace",
                                tint = Color.Red.copy(alpha = 0.8f)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 3. Tactile 3D Circular Keys 3x4 dial pad layout
            val keys = listOf(
                DialerKey("1", ""), DialerKey("2", "A B C"), DialerKey("3", "D E F"),
                DialerKey("4", "G H I"), DialerKey("5", "J K L"), DialerKey("6", "M N O"),
                DialerKey("7", "P Q R S"), DialerKey("8", "T U V"), DialerKey("9", "W X Y Z"),
                DialerKey("*", ""), DialerKey("0", "+"), DialerKey("#", "")
            )

            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                modifier = Modifier
                    .weight(1f)
                    .widthIn(max = 280.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(keys) { key ->
                    Box(
                        modifier = Modifier
                            .aspectRatio(1f)
                            .clip(CircleShape)
                            .background(
                                brush = if (isDark) {
                                    Brush.verticalGradient(listOf(Color(0x1AFFFFFF), Color(0x05FFFFFF)))
                                } else {
                                    Brush.verticalGradient(listOf(Color(0xFFF8FAFC), Color(0xFFE2E8F0)))
                                }
                            )
                            .border(
                                1.dp,
                                if (isDark) Color(0x19FFFFFF) else Color(0x404F46E5),
                                CircleShape
                            )
                            .clickable {
                                if (customNumber.isEmpty()) {
                                    viewModel.customDialNumber = selectedCountry.code + key.digit
                                } else {
                                    viewModel.customDialNumber = customNumber + key.digit
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = key.digit,
                                color = if (isDark) Color.White else Color.Black,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Black
                            )
                            if (key.letters.isNotEmpty()) {
                                Text(
                                    text = key.letters,
                                    color = if (isDark) Color.White.copy(alpha = 0.5f) else Color.Gray,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 4. Neon Launch PSTN Direct Call Button
            ThreeDButton(
                onClick = {
                    val finalNum = if (customNumber.isEmpty()) selectedCountry.code else customNumber
                    viewModel.startPstnCall(finalNum, selectedCountry)
                },
                brandGradientColors = listOf(Color(0xFF10B981), Color(0xFF047857)), // Rich emerald calling colors
                depthColor = Color(0xFF064E3B),
                text = "INJECT SECURE PSTN LINK",
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 16.dp, end = 16.dp, bottom = 4.dp)
            )
        }

        // 5. Interactive Spam & Fraud protection blocking screen/dialog
        if (showSpamAlert) {
            val alertMessage = viewModel.detectedSpamAlert ?: ""
            AlertDialog(
                onDismissRequest = { viewModel.dismissSpamAlert() },
                icon = {
                    Icon(
                        imageVector = Icons.Outlined.Warning,
                        contentDescription = "Spam Warning",
                        tint = Color.Red,
                        modifier = Modifier.size(48.dp)
                    )
                },
                title = {
                    Text(
                        text = "Twilio Fraud Protection Block",
                        fontWeight = FontWeight.Black,
                        color = if (isDark) Color.White else Color.Black,
                        textAlign = TextAlign.Center
                    )
                },
                text = {
                    Text(
                        text = alertMessage,
                        color = if (isDark) Color.White.copy(alpha = 0.7f) else Color.DarkGray,
                        fontSize = 14.sp
                    )
                },
                confirmButton = {
                    Button(
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
                        onClick = {
                            val finalNum = if (customNumber.isEmpty()) selectedCountry.code else customNumber
                            viewModel.overrideSpamWarningAndDial(finalNum, selectedCountry)
                        }
                    ) {
                        Text("Bypass / Override Outflow", color = Color.White)
                    }
                },
                dismissButton = {
                    OutlinedButton(
                        border = BorderStroke(1.dp, Color.Gray),
                        onClick = { viewModel.dismissSpamAlert() }
                    ) {
                        Text("Decline Connection", color = if (isDark) Color.White else Color.Black)
                    }
                },
                containerColor = if (isDark) Color(0xFF181125) else Color.White
            )
        }

        // Insufficient funds dialog wrapper
        if (viewModel.showInsufficientFundsError) {
            AlertDialog(
                onDismissRequest = { viewModel.showInsufficientFundsError = false },
                icon = {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "No Credits",
                        tint = Color(0xFFFBBF24),
                        modifier = Modifier.size(42.dp)
                    )
                },
                title = {
                    Text(
                        text = "Insufficient Call Credit",
                        fontWeight = FontWeight.Bold,
                        color = if (isDark) Color.White else Color.Black
                    )
                },
                text = {
                    Text(
                        text = "This PSTN international call requires at least $${selectedCountry.ratePerMin} credits to connect via standard Twilio SIP routing trunk. Please recharge your wallet in the Telecom settings tab.",
                        fontSize = 14.sp,
                        color = if (isDark) Color.White.copy(alpha = 0.7f) else Color.DarkGray
                    )
                },
                confirmButton = {
                    Button(
                        colors = ButtonDefaults.buttonColors(containerColor = BrandAccent),
                        onClick = { viewModel.showInsufficientFundsError = false }
                    ) {
                        Text("Acknowledge", color = Color.White)
                    }
                },
                containerColor = if (isDark) Color(0xFF13152C) else Color.White
            )
        }
    }
}

data class DialerKey(
    val digit: String,
    val letters: String
)
