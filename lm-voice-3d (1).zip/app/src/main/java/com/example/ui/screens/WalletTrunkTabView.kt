package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.GlassmorphicCard
import com.example.ui.components.ThreeDButton
import com.example.ui.theme.BrandAccent
import com.example.ui.theme.BrandPrimary
import com.example.ui.theme.BrandSecondary
import com.example.viewmodel.AppViewModel

@Composable
fun WalletTrunkTabView(
    viewModel: AppViewModel,
    isDark: Boolean,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    // Local dialog controls
    var showRechargeSuccessAmount by remember { mutableStateOf<Double?>(null) }
    var inputCallerIdPhone by remember { mutableStateOf("") }
    var inputOtpCode by remember { mutableStateOf("") }

    Box(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            
            // 1. FUTURISTIC 3D CREDIT WALLET DISPLAY CARD
            GlassmorphicCard(
                modifier = Modifier.fillMaxWidth(),
                cornerRadius = 24.dp,
                isDarkTheme = isDark
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            brush = Brush.linearGradient(
                                colors = listOf(BrandPrimary.copy(alpha = 0.2f), BrandAccent.copy(alpha = 0.2f))
                            )
                        )
                        .padding(24.dp)
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Wallet,
                                contentDescription = null,
                                tint = BrandAccent,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "GLOBAL PSTN CALL CREDIT",
                                color = if (isDark) Color.White.copy(alpha = 0.6f) else Color.DarkGray,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 2.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "$${String.format("%.2f", viewModel.walletBalance)} USD",
                            color = BrandAccent,
                            fontSize = 38.sp,
                            fontWeight = FontWeight.Black
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "Licensed Outbound Carrier: ${viewModel.selectedVoipProvider}",
                            color = if (isDark) Color.White.copy(alpha = 0.5f) else Color.Gray,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // 2. QUICK RECHARGE PANEL BLOCK
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "QUICK SECURE WALLET TOP-UP",
                    color = BrandAccent,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(5.0, 10.0, 25.0, 50.0).forEach { amount ->
                        Button(
                            onClick = {
                                viewModel.rechargeWallet(amount)
                                showRechargeSuccessAmount = amount
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isDark) Color(0x11FFFFFF) else Color(0xFFF1F5F9)
                            ),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, if (isDark) Color(0x22FFFFFF) else Color(0x224F46E5)),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = "+$${amount.toInt()}",
                                color = if (isDark) Color.White else Color.Black,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                }
            }

            // 3. CARRIER SIP TRUNK CHANNEL CONFIGURATIONS
            GlassmorphicCard(
                modifier = Modifier.fillMaxWidth(),
                cornerRadius = 20.dp,
                isDarkTheme = isDark
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "VOIP OUTBOUND TELECOM TRUNK",
                        color = if (isDark) Color.White else Color.Black,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Selector chips
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("Twilio", "Telnyx", "Plivo").forEach { provider ->
                            val selected = viewModel.selectedVoipProvider == provider
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(
                                        if (selected) BrandAccent.copy(alpha = 0.25f)
                                        else if (isDark) Color(0x0FFFFFFF) else Color(0x0FA1A1AA)
                                    )
                                    .border(
                                        1.dp,
                                        if (selected) BrandAccent else Color.Transparent,
                                        RoundedCornerShape(12.dp)
                                    )
                                    .clickable { viewModel.selectedVoipProvider = provider }
                                    .padding(vertical = 10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = provider,
                                    color = if (selected) BrandAccent else (if (isDark) Color.White.copy(alpha = 0.6f) else Color.DarkGray),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "Provider SID / Master ID",
                        color = if (isDark) Color.White.copy(alpha = 0.6f) else Color.DarkGray,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                    OutlinedTextField(
                        value = viewModel.twilioAccountSid,
                        onValueChange = { viewModel.twilioAccountSid = it },
                        textStyle = LocalTextStyle.current.copy(fontSize = 12.sp),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp),
                        visualTransformation = PasswordVisualTransformation('*')
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Authentication Token / Carrier Key",
                        color = if (isDark) Color.White.copy(alpha = 0.6f) else Color.DarkGray,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                    OutlinedTextField(
                        value = viewModel.twilioAuthToken,
                        onValueChange = { viewModel.twilioAuthToken = it },
                        textStyle = LocalTextStyle.current.copy(fontSize = 12.sp),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp),
                        visualTransformation = PasswordVisualTransformation('*')
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = viewModel.firebaseAuthSimulated,
                            onCheckedChange = { viewModel.firebaseAuthSimulated = it ?: true },
                            colors = CheckboxDefaults.colors(checkedColor = BrandAccent)
                        )
                        Column(modifier = Modifier.padding(start = 4.dp)) {
                            Text(
                                text = "Firebase Token Check",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isDark) Color.White else Color.Black
                            )
                            Text(
                                text = "Enforces secure server-side verification checks",
                                fontSize = 10.sp,
                                color = if (isDark) Color.White.copy(alpha = 0.5f) else Color.Gray
                            )
                        }
                    }
                }
            }

            // 4. OUTBOUND CALLER ID IDENTITY VERIFICATION BINDING
            GlassmorphicCard(
                modifier = Modifier.fillMaxWidth(),
                cornerRadius = 20.dp,
                isDarkTheme = isDark
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "OUTBOUND CALLER ID IDENTITY",
                            color = if (isDark) Color.White else Color.Black,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp
                        )

                        if (viewModel.outboundCallerIdVerified) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFF10B981).copy(alpha = 0.15f))
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.VerifiedUser,
                                    contentDescription = null,
                                    tint = Color(0xFF10B981),
                                    modifier = Modifier.size(12.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "VERIFIED",
                                    color = Color(0xFF10B981),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    if (viewModel.outboundCallerIdVerified) {
                        Column {
                            Text(
                                text = "Currently Bound Voice Line:",
                                fontSize = 12.sp,
                                color = if (isDark) Color.White.copy(alpha = 0.6f) else Color.Gray
                            )
                            Text(
                                text = viewModel.verifiedCallerIdNumber,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = BrandAccent,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "To update or register a new outbound line, request an OTP SMS below.",
                                fontSize = 11.sp,
                                color = if (isDark) Color.White.copy(alpha = 0.4f) else Color.Gray
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    if (!viewModel.verificationOtpSent) {
                        OutlinedTextField(
                            value = inputCallerIdPhone,
                            onValueChange = { inputCallerIdPhone = it },
                            placeholder = { Text("e.g. +1 555 120 4483") },
                            leadingIcon = { Icon(imageVector = Icons.Default.Phone, contentDescription = null) },
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        ThreeDButton(
                            onClick = {
                                if (inputCallerIdPhone.isNotEmpty()) {
                                    viewModel.sendVerificationCode(inputCallerIdPhone)
                                }
                            },
                            brandGradientColors = listOf(BrandPrimary, BrandSecondary),
                            depthColor = BrandPrimary.copy(alpha = 0.6f),
                            text = "REGISTER OUTBOUND LINE / OTP",
                            modifier = Modifier.fillMaxWidth()
                        )
                    } else {
                        // OTP verification controls
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Text(
                                text = "OTP verification SMS sent to ${viewModel.verifiedCallerIdNumber}. Enter code below (Hint: *5239*):",
                                fontSize = 12.sp,
                                color = if (isDark) Color.White.copy(alpha = 0.7f) else Color.DarkGray
                            )

                            OutlinedTextField(
                                value = inputOtpCode,
                                onValueChange = { inputOtpCode = it },
                                placeholder = { Text("Enter 4-Digit Identity OTP Code") },
                                leadingIcon = { Icon(imageVector = Icons.Default.VpnKey, contentDescription = null) },
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 8.dp)
                            )

                            if (viewModel.verificationError != null) {
                                Text(
                                    text = viewModel.verificationError ?: "",
                                    color = Color.Red,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    colors = ButtonDefaults.buttonColors(containerColor = BrandAccent),
                                    onClick = {
                                        val verified = viewModel.verifyCode(inputOtpCode)
                                        if (verified) {
                                            inputOtpCode = ""
                                            inputCallerIdPhone = ""
                                        }
                                    },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Verify Code", color = Color.White)
                                }

                                OutlinedButton(
                                    border = BorderStroke(1.dp, Color.Gray),
                                    onClick = {
                                        viewModel.verificationOtpSent = false
                                        inputOtpCode = ""
                                    }
                                ) {
                                    Text("Cancel", color = if (isDark) Color.White else Color.Black)
                                }
                            }
                        }
                    }
                }
            }

            // 5. AI SPAM AND FRAUD SHIELD CONTROL
            GlassmorphicCard(
                modifier = Modifier.fillMaxWidth(),
                cornerRadius = 20.dp,
                isDarkTheme = isDark
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Security,
                                contentDescription = null,
                                tint = BrandSecondary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "STRICT AI SPAM SHIELD",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isDark) Color.White else Color.Black
                            )
                        }
                        Text(
                            text = "Blocks outgoing or incoming connections flagged by SHAKEN/STIR filters.",
                            fontSize = 11.sp,
                            color = if (isDark) Color.White.copy(alpha = 0.5f) else Color.Gray,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }

                    Switch(
                        checked = viewModel.strictSpamFilterActive,
                        onCheckedChange = { viewModel.strictSpamFilterActive = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = BrandAccent, checkedTrackColor = BrandAccent.copy(alpha = 0.4f))
                    )
                }
            }

            Spacer(modifier = Modifier.height(48.dp)) // Padding bottom for floating navigation
        }

        // Success recharge dialog
        if (showRechargeSuccessAmount != null) {
            val amount = showRechargeSuccessAmount ?: 0.0
            AlertDialog(
                onDismissRequest = { showRechargeSuccessAmount = null },
                icon = {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Success",
                        tint = Color(0xFF10B981),
                        modifier = Modifier.size(54.dp)
                    )
                },
                title = {
                    Text(
                        text = "Credit Top-up Successful!",
                        fontWeight = FontWeight.Black,
                        color = if (isDark) Color.White else Color.Black,
                        textAlign = TextAlign.Center
                    )
                },
                text = {
                    Text(
                        text = "Successfully processed top-up of $${String.format("%.2f", amount)} USD call credits. Standard telecom gateway APIs successfully synched via encrypted master connection.",
                        color = if (isDark) Color.White.copy(alpha = 0.7f) else Color.DarkGray,
                        textAlign = TextAlign.Center
                    )
                },
                confirmButton = {
                    Button(
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                        onClick = { showRechargeSuccessAmount = null }
                    ) {
                        Text("Confirm Balance", color = Color.White)
                    }
                },
                containerColor = if (isDark) Color(0xFF0F1225) else Color.White
            )
        }
    }
}
