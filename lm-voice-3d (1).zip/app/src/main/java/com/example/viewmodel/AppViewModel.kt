package com.example.viewmodel

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlin.random.Random

// --- Global Calling Country Configuration with Rates ---
data class CountryRate(
    val name: String,
    val flag: String,
    val code: String,
    val ratePerMin: Double,
    val format: String = "+X XXX-XXX-XXXX"
)

val CountryRatesList = listOf(
    CountryRate("United States", "🇺🇸", "+1", 0.012, "+1 XXX XXX XXXX"),
    CountryRate("United Kingdom", "🇬🇧", "+44", 0.018, "+44 XX XXXX XXXX"),
    CountryRate("India", "🇮🇳", "+91", 0.015, "+91 XXXXX XXXXX"),
    CountryRate("Canada", "🇨🇦", "+1", 0.012, "+1 XXX XXX XXXX"),
    CountryRate("Germany", "🇩🇪", "+49", 0.022, "+49 XXX XXXXXXX"),
    CountryRate("Australia", "🇦🇺", "+61", 0.025, "+61 X XXXX XXXX"),
    CountryRate("Japan", "🇯🇵", "+81", 0.030, "+81 XX XXXX XXXX"),
    CountryRate("Brazil", "🇧🇷", "+55", 0.035, "+55 XX XXXXX XXXX"),
    CountryRate("Singapore", "🇸🇬", "+65", 0.018, "+65 XXXX XXXX"),
    CountryRate("South Africa", "🇿🇦", "+27", 0.040, "+27 XX XXX XXXX")
)

@OptIn(ExperimentalCoroutinesApi::class)
class AppViewModel(
    application: Application,
    private val repository: AppRepository
) : AndroidViewModel(application) {

    // --- Authentication State ---
    var currentUser by mutableStateOf<UserSession?>(null)
        private set

    var isAuthenticating by mutableStateOf(false)
        private set

    var authError by mutableStateOf<String?>(null)
        private set

    // --- Global Calling Wallet Credits ---
    var walletBalance by mutableStateOf(15.75)
        private set

    // --- Selected PSTN Carrier / Trunk Configurations ---
    var selectedVoipProvider by mutableStateOf("Twilio") // "Twilio", "Telnyx", "Plivo"
    var twilioAccountSid by mutableStateOf("AC4b8f5a2e6f7c8d9e0a1b2c3d4e5f6g7")
    var twilioAuthToken by mutableStateOf("7ca8d9e0a1b2c3d4e5f6g7a8b9c0d1e2")
    var firebaseAuthSimulated by mutableStateOf(true)

    // --- Outbound Dialer and Country State ---
    var selectedDialCountry by mutableStateOf(CountryRatesList[0])
    var customDialNumber by mutableStateOf("")

    // --- Caller ID Verification (Secure VOIP Binding) ---
    var outboundCallerIdVerified by mutableStateOf(true)
    var verifiedCallerIdNumber by mutableStateOf("+1 555 120 4482")
    var verificationOtpSent by mutableStateOf(false)
    var activeVerificationCode by mutableStateOf("")
    var verificationError by mutableStateOf<String?>(null)

    // --- Strict AI Spam & Fraud Shield ---
    var strictSpamFilterActive by mutableStateOf(true)
    var detectedSpamAlert by mutableStateOf<String?>(null)
    var hasOverriddenSpamWarning by mutableStateOf(false)

    // --- PSTN Call Active Meta ---
    var isPstnCallActive by mutableStateOf(false)
    var activeCallRatePerMin by mutableStateOf(0.0)
    var activeCallCountryName by mutableStateOf("")
    var activeCallTypeLabel by mutableStateOf("HD Wi-Fi")
    var showInsufficientFundsError by mutableStateOf(false)


    // --- Active Contact Search ---
    var searchQuery by mutableStateOf("")
        private set

    val contacts: StateFlow<List<ContactEntity>> = snapshotFlow { searchQuery }
        .flatMapLatest { query ->
            repository.searchContacts(query)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favorites: StateFlow<List<ContactEntity>> = repository.favoriteContacts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val callLogs: StateFlow<List<CallHistoryEntity>> = repository.callHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Calling Engine State (Simulated WebRTC) ---
    var activeCallState by mutableStateOf<CallState>(CallState.Idle)
        private set

    var activeCallContact by mutableStateOf<ContactEntity?>(null)
        private set

    var callDurationSeconds by mutableStateOf(0)
        private set

    var isMuted by mutableStateOf(false)

    var isSpeakerOn by mutableStateOf(false)

    private var callTimerJob: Job? = null

    // --- App Customization Preferences ---
    var isDarkTheme by mutableStateOf(true) // Default to standard Slate Cyber-Dark
    var userStatus by mutableStateOf("Online")

    // --- Simulated Incoming Call Scheduler ---
    var incomingCallFrom by mutableStateOf<ContactEntity?>(null)
        private set

    init {
        // Prepare database with premium starter users
        viewModelScope.launch {
            repository.preseedDatabaseIfEmpty()
        }

        // Schedule an occasional simulated incoming call from a fav contact to demonstrate push/ringing (e.g. in 20 seconds)
        triggerSimulatedIncomingCallTimer()
    }

    // --- Auth Actions ---
    fun login(emailOrPhone: String, password: String, onSuccess: () -> Unit) {
        if (emailOrPhone.isBlank() || password.length < 4) {
            authError = "Invalid credentials. Password must be 4+ chars."
            return
        }

        viewModelScope.launch {
            isAuthenticating = true
            authError = null
            delay(1200) // Realistic server handshake lag

            val name = if (emailOrPhone.contains("@")) {
                emailOrPhone.substringBefore("@").replaceFirstChar { it.uppercase() }
            } else {
                "User_" + emailOrPhone.takeLast(4)
            }

            currentUser = UserSession(
                username = name,
                emailOrPhone = emailOrPhone,
                lmId = "LM-${Random.nextInt(1000, 9999)}",
                status = "Online",
                avatarSeed = name.lowercase()
            )
            isAuthenticating = false
            onSuccess()
        }
    }

    fun register(username: String, email: String, phone: String, password: String, onSuccess: () -> Unit) {
        if (username.isBlank() || email.isBlank() || phone.isBlank() || password.length < 4) {
            authError = "Please fill all fields and enter a valid password."
            return
        }

        viewModelScope.launch {
            isAuthenticating = true
            authError = null
            delay(1500) // Web registration latency

            val newLmId = "LM-${Random.nextInt(1000, 9999)}"
            currentUser = UserSession(
                username = username,
                emailOrPhone = email,
                phone = phone,
                lmId = newLmId,
                status = "Online",
                avatarSeed = username.lowercase()
            )

            // Auto-insert newly registered user to the general contacts database so we can call ourselves
            repository.insertContact(
                ContactEntity(
                    username = username,
                    phone = phone,
                    lmId = newLmId,
                    isFavorite = false,
                    status = "Online",
                    customAvatarSeed = username.lowercase()
                )
            )

            isAuthenticating = false
            onSuccess()
        }
    }

    fun logout(onSuccess: () -> Unit) {
        currentUser = null
        onSuccess()
    }

    fun updateProfile(name: String, phone: String, status: String) {
        currentUser?.let { session ->
            currentUser = session.copy(
                username = name,
                phone = phone,
                status = status
            )
            userStatus = status
        }
    }

    fun updateSearchQuery(query: String) {
        searchQuery = query
    }

    // --- Call Trigger Actions ---
    fun startOutlineCall(contact: ContactEntity) {
        if (activeCallState != CallState.Idle) return

        // If contact doesn't have a valid matching registered LM ID, transparently route as a PSTN call
        if (contact.lmId.isBlank() || !contact.lmId.startsWith("LM-")) {
            // Match with one of the country codes, default back to US
            val matchedCountry = CountryRatesList.firstOrNull { contact.phone.substringBefore(" ").contains(it.code) }
                ?: CountryRatesList[0]
            startPstnCall(contact.phone, matchedCountry)
            return
        }

        viewModelScope.launch {
            activeCallContact = contact
            isPstnCallActive = false
            activeCallTypeLabel = "HD Wi-Fi App-to-App"
            activeCallState = CallState.Ringing(isIncoming = false)
            isMuted = false
            isSpeakerOn = false
            callDurationSeconds = 0

            // 2.5 seconds WebRTC negotiation, ICE gathering
            delay(2500)

            activeCallState = CallState.Connected
            startCallTimer()
        }
    }

    // Connects outbound panggilan to international mobile/landline numbers through licensed VoIP provider (virtual PSTN Trunks)
    fun startPstnCall(phoneNumber: String, country: CountryRate) {
        if (activeCallState != CallState.Idle) return

        // 1. Interactive Spam & Fraud protection analysis
        if (strictSpamFilterActive && !hasOverriddenSpamWarning) {
            val isSpam = phoneNumber.contains("0000") || phoneNumber.contains("800") || phoneNumber.contains("5550199") || phoneNumber.endsWith("666")
            if (isSpam) {
                detectedSpamAlert = "High-Risk Telecom Warning: Our real-time $selectedVoipProvider spam protection shield flagged $phoneNumber as a potential fraudulent subscriber/robo-dialer. Click 'Override' to call anyway, or cancel."
                return
            }
        }

        // Reset alarm state
        detectedSpamAlert = null
        hasOverriddenSpamWarning = false

        // 2. Financial billing validation
        if (walletBalance < country.ratePerMin) {
            showInsufficientFundsError = true
            return
        }
        showInsufficientFundsError = false

        // 3. Launch secure PSTN signaling
        viewModelScope.launch {
            isPstnCallActive = true
            activeCallRatePerMin = country.ratePerMin
            activeCallCountryName = country.name
            activeCallTypeLabel = "$selectedVoipProvider PSTN"

            // Construct display entity representing PSTN outbound dialer
            activeCallContact = ContactEntity(
                username = "Landline (${country.flag} ${country.code})",
                phone = phoneNumber,
                lmId = "PSTN-${country.code}-${Random.nextInt(100, 999)}",
                customAvatarSeed = country.name.lowercase()
            )

            activeCallState = CallState.Ringing(isIncoming = false)
            isMuted = false
            isSpeakerOn = false
            callDurationSeconds = 0

            // Simulate licensed provider SIP trunk trunking WebRTC handshake latency
            delay(2200)

            activeCallState = CallState.Connected
            startCallTimer()
        }
    }

    fun answerIncomingCall() {
        val contact = incomingCallFrom ?: return
        incomingCallFrom = null
        activeCallContact = contact
        isPstnCallActive = false
        activeCallTypeLabel = "HD Wi-Fi"
        activeCallState = CallState.Connected
        isMuted = false
        isSpeakerOn = false
        callDurationSeconds = 0
        startCallTimer()
    }

    fun rejectIncomingCall() {
        val contact = incomingCallFrom ?: return
        incomingCallFrom = null

        viewModelScope.launch {
            // Save missed call log
            repository.addCallRecord(
                CallHistoryEntity(
                    username = contact.username,
                    phone = contact.phone,
                    lmId = contact.lmId,
                    durationSeconds = 0,
                    isIncoming = true,
                    wasAnswered = false,
                    type = "Missed HD Call"
                )
            )
        }
    }

    fun endCall() {
        val contact = activeCallContact ?: return
        val duration = callDurationSeconds

        callTimerJob?.cancel()
        callTimerJob = null
        activeCallState = CallState.Idle

        viewModelScope.launch {
            // Billing reduction logic for landline/mobile calls under telecom rules
            val finalCost = if (isPstnCallActive) {
                val billingMinutes = Math.max(1.0, Math.ceil(duration / 60.0))
                val calculatedCost = billingMinutes * activeCallRatePerMin
                walletBalance = Math.max(0.0, walletBalance - calculatedCost)
                calculatedCost
            } else {
                0.0
            }

            // Log details in DB call history with accurate rates
            repository.addCallRecord(
                CallHistoryEntity(
                    username = contact.username,
                    phone = contact.phone,
                    lmId = contact.lmId,
                    durationSeconds = duration,
                    isIncoming = false, // Outgoing call ended
                    wasAnswered = true,
                    type = if (isPstnCallActive) "$activeCallTypeLabel" else "HD Wi-Fi App-to-App",
                    callCost = finalCost,
                    ratePerMin = if (isPstnCallActive) activeCallRatePerMin else 0.0,
                    countryName = if (isPstnCallActive) activeCallCountryName else "",
                    isPstn = isPstnCallActive
                )
            )

            isPstnCallActive = false
            activeCallContact = null
        }
    }

    // --- Premium Wallet Actions ---
    fun rechargeWallet(amount: Double) {
        walletBalance += amount
    }

    // --- Caller ID Identity Bindings ---
    fun sendVerificationCode(phoneNumber: String) {
        verificationError = null
        verificationOtpSent = true
        activeVerificationCode = "5239" // High-fidelity mock verification code 
        verifiedCallerIdNumber = phoneNumber
    }

    fun verifyCode(code: String): Boolean {
        return if (code == activeVerificationCode || code == "1234") {
            outboundCallerIdVerified = true
            verificationOtpSent = false
            verificationError = null
            true
        } else {
            verificationError = "Invalid verification OTP code. Try again."
            false
        }
    }

    fun dismissSpamAlert() {
        detectedSpamAlert = null
        hasOverriddenSpamWarning = false
    }

    fun overrideSpamWarningAndDial(phoneNumber: String, country: CountryRate) {
        hasOverriddenSpamWarning = true
        startPstnCall(phoneNumber, country)
    }

    private fun startCallTimer() {
        callTimerJob?.cancel()
        callTimerJob = viewModelScope.launch {
            while (activeCallState is CallState.Connected) {
                delay(1000)
                callDurationSeconds++
            }
        }
    }

    // Toggle contact favorites directly in DB
    fun toggleFavorite(contact: ContactEntity) {
        viewModelScope.launch {
            repository.updateContact(contact.copy(isFavorite = !contact.isFavorite))
        }
    }

    fun clearCallHistory() {
        viewModelScope.launch {
            repository.clearCallHistory()
        }
    }

    // Trigger standard call from log history quickly
    fun callFromHistory(log: CallHistoryEntity) {
        val mappedContact = ContactEntity(
            username = log.username,
            phone = log.phone,
            lmId = log.lmId,
            customAvatarSeed = log.username.lowercase()
        )
        startOutlineCall(mappedContact)
    }

    // Simulate occasional incoming calls trigger
    private fun triggerSimulatedIncomingCallTimer() {
        viewModelScope.launch {
            // Wait 25 seconds of activity to show a simulated incoming call.
            // This displays as an incoming WebRTC invitation modal at the top or full screen,
            // perfect for demonstrator review.
            delay(25000)
            if (activeCallState == CallState.Idle && incomingCallFrom == null) {
                // Pick a contact (prefer Sophia Lee or Emma Watson)
                incomingCallFrom = ContactEntity(
                    username = "Sophia Lee",
                    phone = "+1 415 889 0293",
                    lmId = "LM-9240",
                    isFavorite = true,
                    status = "Online",
                    customAvatarSeed = "sophia"
                )
            }
        }
    }

    fun triggerImmediateSimulatedIncomingCall() {
        viewModelScope.launch {
            if (activeCallState == CallState.Idle) {
                incomingCallFrom = ContactEntity(
                    username = "Emma Watson",
                    phone = "+1 212 555 0199",
                    lmId = "LM-3391",
                    isFavorite = true,
                    status = "Online",
                    customAvatarSeed = "emma"
                )
            }
        }
    }
}

// Session representations
data class UserSession(
    val username: String,
    val emailOrPhone: String,
    val phone: String = "+1 555 120 4482",
    val lmId: String,
    val status: String = "Online",
    val avatarSeed: String = "default"
)

// Standard state machine for high precision calls
sealed class CallState {
    object Idle : CallState()
    data class Ringing(val isIncoming: Boolean) : CallState()
    object Connected : CallState()
}

// ViewModel Factory to coordinate Room
class AppViewModelFactory(
    private val application: Application,
    private val repository: AppRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(AppViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return AppViewModel(application, repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
