package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.ViewModelProvider
import com.example.data.AppDatabase
import com.example.data.AppRepository
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.CallScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.ProfileSettingsScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.AppViewModel
import com.example.viewmodel.AppViewModelFactory
import com.example.viewmodel.CallState

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // 1. Initialize DB and Repository
        val database = AppDatabase.getDatabase(this)
        val repository = AppRepository(database)

        // 2. Build ViewModel
        val factory = AppViewModelFactory(application, repository)
        val viewModel = ViewModelProvider(this, factory)[AppViewModel::class.java]

        setContent {
            // Observe custom theme toggle from settings
            val isDark = viewModel.isDarkTheme

            MyApplicationTheme(darkTheme = isDark, dynamicColor = false) {
                // Navigation Screen Router
                var currentScreen by remember { mutableStateOf(AppScreen.Auth) }

                // Auto redirect to dashboard if authenticated
                LaunchedEffect(viewModel.currentUser) {
                    if (viewModel.currentUser != null) {
                        currentScreen = AppScreen.Dashboard
                    } else {
                        currentScreen = AppScreen.Auth
                    }
                }

                BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                    Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                        // Crossfade gives beautiful premium animated page transitions
                        Crossfade(
                            targetState = currentScreen,
                            animationSpec = tween(durationMillis = 400, easing = FastOutSlowInEasing),
                            label = "PageTransitions"
                        ) { screen ->
                            when (screen) {
                                AppScreen.Auth -> {
                                    AuthScreen(
                                        viewModel = viewModel,
                                        onAuthSuccess = {
                                            currentScreen = AppScreen.Dashboard
                                        }
                                    )
                                }
                                AppScreen.Dashboard -> {
                                    DashboardScreen(
                                        viewModel = viewModel,
                                        onNavigateToProfile = {
                                            currentScreen = AppScreen.ProfileSettings
                                        }
                                    )
                                }
                                AppScreen.ProfileSettings -> {
                                    ProfileSettingsScreen(
                                        viewModel = viewModel,
                                        onNavigateBack = {
                                            currentScreen = AppScreen.Dashboard
                                        },
                                        onLogoutSuccess = {
                                            currentScreen = AppScreen.Auth
                                        }
                                    )
                                }
                            }
                        }
                    }

                    // 3. VOICE CALLING FLOATING OVERLAY
                    // When call state is active (Ringing or Connected), overlay the full-screen interactive CallScreen immediately
                    AnimatedVisibility(
                        visible = viewModel.activeCallState != CallState.Idle,
                        enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                        exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
                    ) {
                        CallScreen(
                            viewModel = viewModel,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
            }
        }
    }
}

// Navigation Enum representing pages
enum class AppScreen {
    Auth,
    Dashboard,
    ProfileSettings
}
