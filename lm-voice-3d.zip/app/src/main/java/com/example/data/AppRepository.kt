package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

class AppRepository(private val database: AppDatabase) {
    private val contactDao = database.contactDao()
    private val callHistoryDao = database.callHistoryDao()

    val allContacts: Flow<List<ContactEntity>> = contactDao.getAllContacts()
    val favoriteContacts: Flow<List<ContactEntity>> = contactDao.getFavoriteContacts()
    val callHistory: Flow<List<CallHistoryEntity>> = callHistoryDao.getAllCalls()

    fun searchContacts(query: String): Flow<List<ContactEntity>> {
        if (query.isBlank()) return allContacts
        val likeQuery = "%$query%"
        return contactDao.searchContacts(likeQuery)
    }

    suspend fun insertContact(contact: ContactEntity) {
        contactDao.insertContact(contact)
    }

    suspend fun updateContact(contact: ContactEntity) {
        contactDao.updateContact(contact)
    }

    suspend fun deleteContact(contact: ContactEntity) {
        contactDao.deleteContact(contact)
    }

    suspend fun addCallRecord(call: CallHistoryEntity) {
        callHistoryDao.insertCall(call)
    }

    suspend fun deleteCallRecord(id: Int) {
        callHistoryDao.deleteCallById(id)
    }

    suspend fun clearCallHistory() {
        callHistoryDao.clearHistory()
    }

    // Pre-populate database with cool luxury futuristic calling avatars and details
    suspend fun preseedDatabaseIfEmpty() {
        if (contactDao.getCount() == 0) {
            val defaultContacts = listOf(
                ContactEntity(
                    username = "Sophia Lee",
                    phone = "+1 415 889 0293",
                    lmId = "LM-9240",
                    isFavorite = true,
                    status = "Online",
                    customAvatarSeed = "sophia"
                ),
                ContactEntity(
                    username = "Liam Vance",
                    phone = "+1 310 405 8812",
                    lmId = "LM-8812",
                    isFavorite = true,
                    status = "Online",
                    customAvatarSeed = "liam"
                ),
                ContactEntity(
                    username = "Amelia Sterling",
                    phone = "+44 207 946 0192",
                    lmId = "LM-5100",
                    isFavorite = false,
                    status = "Busy",
                    customAvatarSeed = "amelia"
                ),
                ContactEntity(
                    username = "Marcus Aurelius",
                    phone = "+39 06 1204 9912",
                    lmId = "LM-1249",
                    isFavorite = false,
                    status = "Offline",
                    customAvatarSeed = "marcus"
                ),
                ContactEntity(
                    username = "Emma Watson",
                    phone = "+1 212 555 0199",
                    lmId = "LM-3391",
                    isFavorite = true,
                    status = "Online",
                    customAvatarSeed = "emma"
                ),
                ContactEntity(
                    username = "James Carter",
                    phone = "+1 650 338 1203",
                    lmId = "LM-5120",
                    isFavorite = false,
                    status = "Offline",
                    customAvatarSeed = "james"
                )
            )
            contactDao.insertContacts(defaultContacts)

            // Seed some default call logs
            val defaultLogs = listOf(
                CallHistoryEntity(
                    username = "Sophia Lee",
                    phone = "+1 415 889 0293",
                    lmId = "LM-9240",
                    timestamp = System.currentTimeMillis() - 3600000, // 1 hour ago
                    durationSeconds = 245,
                    isIncoming = true,
                    wasAnswered = true,
                    type = "HD Wi-Fi"
                ),
                CallHistoryEntity(
                    username = "Marcus Aurelius",
                    phone = "+39 06 1204 9912",
                    lmId = "LM-1249",
                    timestamp = System.currentTimeMillis() - (3600000 * 5), // 5 hours ago
                    durationSeconds = 0,
                    isIncoming = false,
                    wasAnswered = false,
                    type = "Missed HD Call"
                ),
                CallHistoryEntity(
                    username = "Liam Vance",
                    phone = "+1 310 405 8812",
                    lmId = "LM-8812",
                    timestamp = System.currentTimeMillis() - 86400000, // 1 day ago
                    durationSeconds = 1120,
                    isIncoming = false,
                    wasAnswered = true,
                    type = "3D Direct Calling"
                )
            )
            for (log in defaultLogs) {
                callHistoryDao.insertCall(log)
            }
        }
    }
}
