package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "contacts")
data class ContactEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val username: String,
    val phone: String,
    val lmId: String,
    val isFavorite: Boolean = false,
    val avatarUrl: String = "",
    val status: String = "Offline",
    val customAvatarSeed: String = ""
)
