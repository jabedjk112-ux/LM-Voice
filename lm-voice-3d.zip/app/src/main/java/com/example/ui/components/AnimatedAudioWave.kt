package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.BrandAccent
import com.example.ui.theme.BrandPrimary

@Composable
fun AnimatedAudioWave(
    modifier: Modifier = Modifier,
    active: Boolean = true,
    barWidth: Dp = 6.dp,
    maxHeight: Dp = 60.dp,
    minHeight: Dp = 8.dp,
    gradientColors: List<Color> = listOf(BrandAccent, BrandPrimary)
) {
    val barCount = 9
    val infiniteTransition = rememberInfiniteTransition(label = "audioWave")

    // Define different speeds/durations for visual asynchronous complexity
    val durations = listOf(650, 450, 800, 350, 700, 500, 750, 400, 600)

    val scaleAnims = (0 until barCount).map { i ->
        if (active) {
            infiniteTransition.animateFloat(
                initialValue = 0.15f,
                targetValue = 1.0f,
                animationSpec = infiniteRepeatable(
                    animation = tween(durations[i], easing = FastOutSlowInEasing),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "barScale_$i"
            )
        } else {
            remember { mutableStateOf(0.15f) }
        }
    }

    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        for (i in 0 until barCount) {
            val scale = scaleAnims[i].value
            // Interpolate heights
            val computedHeight = minHeight + (maxHeight - minHeight) * scale

            Box(
                modifier = Modifier
                    .width(barWidth)
                    .height(computedHeight)
                    .clip(RoundedCornerShape(percent = 50))
                    .background(
                        brush = Brush.verticalGradient(gradientColors)
                    )
            )
        }
    }
}
