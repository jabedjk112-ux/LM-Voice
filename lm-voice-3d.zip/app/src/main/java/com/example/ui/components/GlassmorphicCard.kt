package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.DarkGlassBody
import com.example.ui.theme.DarkGlassBorder
import com.example.ui.theme.LightGlassBody
import com.example.ui.theme.LightGlassBorder

@Composable
fun GlassmorphicCard(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 24.dp,
    borderWidth: Dp = 1.dp,
    isDarkTheme: Boolean = true,
    content: @Composable BoxScope.() -> Unit
) {
    val bodyColor = if (isDarkTheme) DarkGlassBody else LightGlassBody
    val borderColor = if (isDarkTheme) DarkGlassBorder else LightGlassBorder

    val shape = RoundedCornerShape(cornerRadius)

    val shadowColor = if (isDarkTheme) {
        Color(0x7F0B0F19)
    } else {
        Color(0x1A4F46E5)
    }

    Box(
        modifier = modifier
            .shadow(
                elevation = 8.dp,
                shape = shape,
                clip = false,
                ambientColor = shadowColor,
                spotColor = shadowColor
            )
            .clip(shape)
            .background(bodyColor)
            .border(
                width = borderWidth,
                brush = Brush.linearGradient(
                    colors = listOf(
                        borderColor,
                        borderColor.copy(alpha = 0.05f),
                        borderColor
                    )
                ),
                shape = shape
            )
            .padding(16.dp)
    ) {
        content()
    }
}
