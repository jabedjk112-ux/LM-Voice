package com.example.ui.components

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.BrandPrimary
import com.example.ui.theme.BrandSecondary

@Composable
fun ThreeDButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    text: String = "",
    cornerRadius: Dp = 16.dp,
    brandGradientColors: List<Color> = listOf(BrandPrimary, BrandSecondary),
    depthColor: Color = Color(0xFF312E81), // Darker indigo
    enabled: Boolean = true,
    content: @Composable (BoxScope.() -> Unit)? = null
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    // Smooth physical transition
    val buttonDepth = 6.dp
    val pressOffset by animateDpAsState(
        targetValue = if (isPressed && enabled) buttonDepth else 0.dp,
        animationSpec = tween(durationMillis = 100),
        label = "Button3DPress"
    )

    Box(
        modifier = modifier
            .width(IntrinsicSize.Max)
            .height(IntrinsicSize.Max)
            .padding(bottom = buttonDepth) // Allocate space for 3D depth anchor
    ) {
        // 1. The Under-slab (The 3D physical thickness/bezel)
        Box(
            modifier = Modifier
                .matchParentSize()
                .offset(y = buttonDepth)
                .clip(RoundedCornerShape(cornerRadius))
                .background(if (enabled) depthColor else Color.Gray.copy(alpha = 0.5f))
        )

        // 2. The Face-plate (Moving interactive layer)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .offset(y = pressOffset)
                .clip(RoundedCornerShape(cornerRadius))
                .background(
                    if (enabled) {
                        Brush.linearGradient(brandGradientColors)
                    } else {
                        Brush.linearGradient(listOf(Color.LightGray, Color.Gray))
                    }
                )
                .clickable(
                    interactionSource = interactionSource,
                    indication = null, // No standard flat ripple; tactile offset is the interaction itself!
                    enabled = enabled,
                    onClick = onClick
                )
                .padding(horizontal = 24.dp, vertical = 14.dp),
            contentAlignment = Alignment.Center
        ) {
            if (content != null) {
                content()
            } else {
                Text(
                    text = text,
                    color = Color.White,
                    style = androidx.compose.material3.MaterialTheme.typography.titleMedium
                )
            }
        }
    }
}
