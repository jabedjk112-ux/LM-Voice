package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.GlassmorphicCard
import com.example.ui.components.GlassmorphicTextField
import com.example.ui.components.ThreeDButton
import com.example.ui.theme.*
import com.example.viewmodel.AppViewModel

@Composable
fun AuthScreen(
    viewModel: AppViewModel,
    onAuthSuccess: () -> Unit
) {
    var isSignUpMode by remember { mutableStateOf(false) }
    val focusManager = LocalFocusManager.current
    val scrollState = rememberScrollState()

    // Form inputs
    var username by remember { mutableStateOf("") }
    var emailOrPhone by remember { mutableStateOf("") }
    var userPhone by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }

    val isDark = viewModel.isDarkTheme

    // Linear cyber space backgrounds
    val gradientBackground = if (isDark) {
        Brush.verticalGradient(colors = listOf(DarkBgStart, DarkBgEnd))
    } else {
        Brush.verticalGradient(colors = listOf(LightBgStart, LightBgEnd))
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(gradientBackground)
            .imePadding()
            .navigationBarsPadding()
            .statusBarsPadding(),
        contentAlignment = Alignment.Center
    ) {
        // Decorative Neon Ambient Glow rings
        Box(
            modifier = Modifier
                .size(300.dp)
                .align(Alignment.TopEnd)
                .offset(x = 100.dp, y = (-80).dp)
                .background(
                    brush = Brush.radialGradient(
                        colors = listOf(CyberPurpleGlow.copy(alpha = 0.25f), Color.Transparent)
                    )
                )
        )
        Box(
            modifier = Modifier
                .size(350.dp)
                .align(Alignment.BottomStart)
                .offset(x = (-120).dp, y = 120.dp)
                .background(
                    brush = Brush.radialGradient(
                        colors = listOf(CyberCyanGlow.copy(alpha = 0.25f), Color.Transparent)
                    )
                )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Brand Logo Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier.padding(bottom = 8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(
                            brush = Brush.linearGradient(
                                colors = listOf(BrandAccent, BrandSecondary)
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.VolumeUp,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(28.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "LM VOICE 3D",
                        color = if (isDark) Color.White else Color(0xFF1E1B4B),
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.5.sp
                    )
                    Text(
                        text = "PREMIUM WI-FI CALLING UNLIMITED",
                        color = if (isDark) BrandAccent else BrandPrimary,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            // Main Auth Form
            GlassmorphicCard(
                modifier = Modifier.fillMaxWidth(),
                isDarkTheme = isDark
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Title
                    Text(
                        text = if (isSignUpMode) "Create LM Account" else "Welcome Back",
                        color = if (isDark) Color.White else Color(0xFF1E1B4B),
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 4.dp)
                    )
                    Text(
                        text = if (isSignUpMode) "Register below for crystal clear 3D voice calls" else "Sign in to resume secure connection",
                        color = if (isDark) Color.White.copy(alpha = 0.6f) else Color.Gray,
                        fontSize = 12.sp,
                        textAlign = Alignment.CenterHorizontally.let { TextAlign.Center },
                        modifier = Modifier.padding(bottom = 20.dp)
                    )

                    // Error indicator
                    viewModel.authError?.let { err ->
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 16.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0x33EF4444))
                                .padding(12.dp)
                        ) {
                            Text(
                                text = err,
                                color = Color(0xFFFCA5A5),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    // Mode Fields Switch
                    if (isSignUpMode) {
                        GlassmorphicTextField(
                            value = username,
                            onValueChange = { username = it },
                            placeholder = "Username (e.g., Alice Vance)",
                            leadingIcon = Icons.Default.Person,
                            isDarkTheme = isDark,
                            modifier = Modifier.padding(bottom = 12.dp)
                        )

                        GlassmorphicTextField(
                            value = emailOrPhone,
                            onValueChange = { emailOrPhone = it },
                            placeholder = "Gmail or primary email",
                            leadingIcon = Icons.Default.Mail,
                            isDarkTheme = isDark,
                            modifier = Modifier.padding(bottom = 12.dp)
                        )

                        GlassmorphicTextField(
                            value = userPhone,
                            onValueChange = { userPhone = it },
                            placeholder = "Mobile phone number",
                            leadingIcon = Icons.Default.Phone,
                            isDarkTheme = isDark,
                            modifier = Modifier.padding(bottom = 12.dp)
                        )
                    } else {
                        // Login Mode inputs
                        GlassmorphicTextField(
                            value = emailOrPhone,
                            onValueChange = { emailOrPhone = it },
                            placeholder = "Email or phone number",
                            leadingIcon = Icons.Default.AccountCircle,
                            isDarkTheme = isDark,
                            modifier = Modifier.padding(bottom = 12.dp)
                        )
                    }

                    GlassmorphicTextField(
                        value = password,
                        onValueChange = { password = it },
                        placeholder = "Password (min 4 characters)",
                        leadingIcon = Icons.Default.Lock,
                        visualTransformation = PasswordVisualTransformation(),
                        isDarkTheme = isDark,
                        modifier = Modifier.padding(bottom = 24.dp)
                    )

                    // Submission 3D Button
                    if (viewModel.isAuthenticating) {
                        CircularProgressIndicator(
                            color = BrandAccent,
                            modifier = Modifier.size(36.dp)
                        )
                    } else {
                        ThreeDButton(
                            onClick = {
                                focusManager.clearFocus()
                                if (isSignUpMode) {
                                    viewModel.register(
                                        username = username,
                                        email = emailOrPhone,
                                        phone = userPhone,
                                        password = password,
                                        onSuccess = onAuthSuccess
                                    )
                                } else {
                                    viewModel.login(
                                        emailOrPhone = emailOrPhone,
                                        password = password,
                                        onSuccess = onAuthSuccess
                                    )
                                }
                            },
                            text = if (isSignUpMode) "Register Securely" else "Secure Login",
                            brandGradientColors = listOf(BrandPrimary, BrandSecondary),
                            depthColor = Color(0xFF312E81),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Mode toggle
                    Row(
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = if (isSignUpMode) "Already have an account?" else "New to LM Voice?",
                            color = if (isDark) Color.White.copy(alpha = 0.6f) else Color.Gray,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isSignUpMode) "Login Now" else "Register Free",
                            color = BrandAccent,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .clickable {
                                    isSignUpMode = !isSignUpMode
                                    viewModel.login("", "") {} // Clear error, clean-up
                                }
                                .padding(vertical = 4.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Social/Shorthand Login Shortcuts (as specified: Registration with Gmail, etc.)
            Text(
                text = "OR SIGN IN WITH",
                color = if (isDark) Color.White.copy(alpha = 0.4f) else Color.Gray.copy(alpha = 0.7f),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Gmail quick login
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .clip(CircleShape)
                        .background(if (isDark) Color(0x1AFFFFFF) else Color(0xCCFFFFFF))
                        .clickable {
                            // Instant Gmail mock login
                            viewModel.login("jabedjk41@gmail.com", "google-oauth-flow") {
                                onAuthSuccess()
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Mail,
                        contentDescription = "Gmail OAuth",
                        tint = Color(0xFFEA4335), // Google Red
                        modifier = Modifier.size(24.dp)
                    )
                }

                // Phone quick login
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .clip(CircleShape)
                        .background(if (isDark) Color(0x1AFFFFFF) else Color(0xCCFFFFFF))
                        .clickable {
                            viewModel.login("+1 555 120 4482", "phone-flow") {
                                onAuthSuccess()
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Phone,
                        contentDescription = "Quick Phone OTP",
                        tint = BrandAccent,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }
    }
}
