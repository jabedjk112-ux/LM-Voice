package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CallHistoryEntity
import com.example.data.ContactEntity
import com.example.ui.components.GlassmorphicCard
import com.example.ui.components.GlassmorphicTextField
import com.example.ui.components.ThreeDButton
import com.example.ui.theme.BrandAccent
import com.example.ui.theme.BrandPrimary
import com.example.ui.theme.BrandSecondary
import com.example.viewmodel.AppViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun DashboardScreen(
    viewModel: AppViewModel,
    onNavigateToProfile: () -> Unit,
    modifier: Modifier = Modifier
) {
    val contacts by viewModel.contacts.collectAsState()
    val favorites by viewModel.favorites.collectAsState()
    val logs by viewModel.callLogs.collectAsState()
    val currentUser = viewModel.currentUser

    val isDark = viewModel.isDarkTheme

    // Outer background styling
    val backgroundBrush = if (isDark) {
        Brush.verticalGradient(listOf(Color(0xFF0A0C1D), Color(0xFF14172E)))
    } else {
        Brush.verticalGradient(listOf(Color(0xFFF2F4FC), Color(0xFFE3E5FA)))
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(backgroundBrush)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // 1. Sleek Dashboard Top bar Custom header
            DashboardHeader(
                currentUser = currentUser,
                userStatus = viewModel.userStatus,
                isDark = isDark,
                onToggleTheme = { viewModel.isDarkTheme = !viewModel.isDarkTheme },
                onProfileClick = onNavigateToProfile,
                onInstantIncomingSimulate = { viewModel.triggerImmediateSimulatedIncomingCall() }
            )

            // Scrollable Content
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(24.dp)
            ) {
                // 2. Large Interactive Search Bar
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "Find Connections",
                            color = if (isDark) Color.White.copy(alpha = 0.5f) else Color.Gray,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.2.sp
                        )
                        GlassmorphicTextField(
                            value = viewModel.searchQuery,
                            onValueChange = { viewModel.updateSearchQuery(it) },
                            placeholder = "Search username, phone, or LM ID...",
                            leadingIcon = Icons.Default.Search,
                            trailingIcon = {
                                if (viewModel.searchQuery.isNotEmpty()) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Clear",
                                        tint = if (isDark) Color.White else Color.Black,
                                        modifier = Modifier.clickable { viewModel.updateSearchQuery("") }
                                    )
                                }
                            },
                            isDarkTheme = isDark
                        )
                    }
                }

                // 3. Horizontal Favorite Contacts Carousel
                if (favorites.isNotEmpty() && viewModel.searchQuery.isEmpty()) {
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Star,
                                        contentDescription = null,
                                        tint = BrandAccent,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "FAVORITE CONTACTS",
                                        color = if (isDark) Color.White else Color(0xFF1E1B4B),
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Black,
                                        letterSpacing = 1.sp
                                    )
                                }
                                Text(
                                    text = "${favorites.size} Pinned",
                                    color = BrandAccent,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            LazyRow(
                                horizontalArrangement = Arrangement.spacedBy(14.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                items(favorites) { favorite ->
                                    FavoriteContactCard(
                                        contact = favorite,
                                        isDark = isDark,
                                        onCallClick = { viewModel.startOutlineCall(favorite) },
                                        onToggleFav = { viewModel.toggleFavorite(favorite) }
                                    )
                                }
                            }
                        }
                    }
                }

                // 4. Contact List (or search results)
                item {
                    val labelText = if (viewModel.searchQuery.isNotEmpty()) "SEARCH RESULTS" else "DIRECT DIAL CONTACTS"
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = labelText,
                                color = if (isDark) Color.White else Color(0xFF1E1B4B),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = "${contacts.size} available",
                                color = if (isDark) Color.White.copy(alpha = 0.5f) else Color.Gray,
                                fontSize = 11.sp
                            )
                        }

                        if (contacts.isEmpty()) {
                            // Empty State
                            GlassmorphicCard(
                                modifier = Modifier.fillMaxWidth(),
                                isDarkTheme = isDark
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.Contacts,
                                        contentDescription = null,
                                        tint = BrandAccent,
                                        modifier = Modifier.size(36.dp)
                                    )
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Text(
                                        text = "No Contacts Found",
                                        color = if (isDark) Color.White else Color.Black,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Check spelling or search by LM ID",
                                        color = if (isDark) Color.White.copy(alpha = 0.5f) else Color.Gray,
                                        fontSize = 12.sp,
                                        modifier = Modifier.padding(top = 2.dp)
                                    )
                                }
                            }
                        } else {
                            contacts.forEach { contact ->
                                ContactItemRow(
                                    contact = contact,
                                    isDark = isDark,
                                    onCallClick = { viewModel.startOutlineCall(contact) },
                                    onFavClick = { viewModel.toggleFavorite(contact) }
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                            }
                        }
                    }
                }

                // 5. Recent Calls Section
                if (viewModel.searchQuery.isEmpty()) {
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.History,
                                        contentDescription = null,
                                        tint = BrandSecondary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "RECENT VOIP CALLS",
                                        color = if (isDark) Color.White else Color(0xFF1E1B4B),
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Black,
                                        letterSpacing = 1.sp
                                    )
                                }

                                if (logs.isNotEmpty()) {
                                    Text(
                                        text = "Clear All",
                                        color = Color.Red.copy(alpha = 0.8f),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.clickable { viewModel.clearCallHistory() }
                                    )
                                }
                            }

                            if (logs.isEmpty()) {
                                GlassmorphicCard(
                                    modifier = Modifier.fillMaxWidth(),
                                    isDarkTheme = isDark
                                ) {
                                    Text(
                                        text = "No recent VOIP logs. Make a 3D call now! ✨",
                                        color = if (isDark) Color.White.copy(alpha = 0.5f) else Color.DarkGray,
                                        fontSize = 12.sp,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp)
                                    )
                                }
                            } else {
                                logs.forEach { log ->
                                    RecentCallRow(
                                        log = log,
                                        isDark = isDark,
                                        onCallClick = { viewModel.callFromHistory(log) }
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                }
                            }
                        }
                    }
                }
            }
        }

        // 6. Sliding floating Incoming Call simulated notification banner
        AnimatedVisibility(
            visible = viewModel.incomingCallFrom != null,
            enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut(),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(16.dp)
        ) {
            val incoming = viewModel.incomingCallFrom
            if (incoming != null) {
                IncomingCallBanner(
                    contact = incoming,
                    isDark = isDark,
                    onAccept = { viewModel.answerIncomingCall() },
                    onDecline = { viewModel.rejectIncomingCall() }
                )
            }
        }
    }
}

// 1. Dashboard Header
@Composable
fun DashboardHeader(
    currentUser: com.example.viewmodel.UserSession?,
    userStatus: String,
    isDark: Boolean,
    onToggleTheme: () -> Unit,
    onProfileClick: () -> Unit,
    onInstantIncomingSimulate: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Left User Identity Profile Block
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.clickable { onProfileClick() }
        ) {
            Box(
                contentAlignment = Alignment.BottomEnd,
                modifier = Modifier.size(46.dp)
            ) {
                // Avatar
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(CircleShape)
                        .background(
                            brush = Brush.linearGradient(
                                colors = listOf(BrandAccent, BrandSecondary)
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = currentUser?.username?.split(" ")?.map { it.take(1) }?.joinToString("") ?: "LM",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Active online badge node
                Box(
                    modifier = Modifier
                        .size(14.dp)
                        .clip(CircleShape)
                        .border(2.dp, if (isDark) Color(0xFF0A0C1D) else Color.White, CircleShape)
                        .background(
                            when (userStatus) {
                                "Online" -> Color.Green
                                "Busy" -> Color.Red
                                else -> Color.Gray
                            }
                        )
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column {
                Text(
                    text = currentUser?.username ?: "LM Caller",
                    color = if (isDark) Color.White else Color(0xFF1E1B4B),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Black
                )
                Text(
                    text = currentUser?.lmId ?: "ID: LM-0000",
                    color = BrandAccent,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Action icons (Dark toggle, manual simulator trigger, settings)
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Simulated incoming caller injector
            IconButton(
                onClick = onInstantIncomingSimulate,
                colors = IconButtonDefaults.iconButtonColors(
                    containerColor = if (isDark) Color(0x11FFFFFF) else Color(0x194F46E5)
                )
            ) {
                Icon(
                    imageVector = Icons.Default.RingVolume,
                    contentDescription = "Trigger Incoming Call",
                    tint = BrandAccent,
                    modifier = Modifier.size(20.dp)
                )
            }

            // Light/Dark Toggle
            IconButton(
                onClick = onToggleTheme,
                colors = IconButtonDefaults.iconButtonColors(
                    containerColor = if (isDark) Color(0x11FFFFFF) else Color(0x194F46E5)
                )
            ) {
                Icon(
                    imageVector = if (isDark) Icons.Default.LightMode else Icons.Default.DarkMode,
                    contentDescription = "Theme Toggle",
                    tint = if (isDark) Color.Yellow else BrandPrimary,
                    modifier = Modifier.size(20.dp)
                )
            }

            // Go to Settings page
            IconButton(
                onClick = onProfileClick,
                colors = IconButtonDefaults.iconButtonColors(
                    containerColor = if (isDark) Color(0x11FFFFFF) else Color(0x194F46E5)
                )
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = "Settings",
                    tint = if (isDark) Color.White else Color.Black,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

// 3. Horizontal Favorite card
@Composable
fun FavoriteContactCard(
    contact: ContactEntity,
    isDark: Boolean,
    onCallClick: () -> Unit,
    onToggleFav: () -> Unit
) {
    GlassmorphicCard(
        modifier = Modifier
            .width(136.dp)
            .wrapContentHeight(),
        cornerRadius = 18.dp,
        isDarkTheme = isDark
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            // Heart toggle tag
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                Icon(
                    imageVector = Icons.Default.Favorite,
                    contentDescription = "Fav",
                    tint = BrandSecondary,
                    modifier = Modifier
                        .size(16.dp)
                        .clickable { onToggleFav() }
                )
            }

            // Avatar circle
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .clip(CircleShape)
                    .background(
                        brush = Brush.radialGradient(
                            colors = listOf(BrandAccent.copy(alpha = 0.4f), Color.Transparent)
                        )
                    )
                    .border(1.dp, BrandAccent.copy(alpha = 0.6f), CircleShape)
                    .padding(4.dp)
                    .clip(CircleShape)
                    .background(if (isDark) Color(0xFF13152C) else Color.White),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = contact.username.split(" ").map { it.take(1) }.joinToString(""),
                    color = BrandAccent,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Text
            Text(
                text = contact.username,
                color = if (isDark) Color.White else Color.Black,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Text(
                text = contact.lmId,
                color = if (isDark) Color.White.copy(alpha = 0.5f) else Color.Gray,
                fontSize = 10.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            // 3D Call Action Button inside card
            ThreeDButton(
                onClick = onCallClick,
                brandGradientColors = listOf(BrandAccent, BrandPrimary),
                depthColor = Color(0xFF0369A1),
                cornerRadius = 10.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(34.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxSize()
                ) {
                    Icon(
                        imageVector = Icons.Default.Call,
                        contentDescription = "Call",
                        tint = Color.White,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "CALL",
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

// 4. Contact Item Row
@Composable
fun ContactItemRow(
    contact: ContactEntity,
    isDark: Boolean,
    onCallClick: () -> Unit,
    onFavClick: () -> Unit
) {
    GlassmorphicCard(
        modifier = Modifier.fillMaxWidth(),
        cornerRadius = 16.dp,
        isDarkTheme = isDark
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                // Glass avatar indicator
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(if (isDark) Color(0x33FFFFFF) else Color(0x194F46E5)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = contact.username.split(" ").map { it.take(1) }.joinToString(""),
                        color = if (isDark) BrandAccent else BrandPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Black
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = contact.username,
                        color = if (isDark) Color.White else Color.Black,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${contact.lmId} • ${contact.phone}",
                        color = if (isDark) Color.White.copy(alpha = 0.5f) else Color.Gray,
                        fontSize = 11.sp
                    )
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Favorite Heart icon
                IconButton(onClick = onFavClick) {
                    Icon(
                        imageVector = if (contact.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Favorite",
                        tint = if (contact.isFavorite) BrandSecondary else if (isDark) Color.White.copy(alpha = 0.4f) else Color.Gray
                    )
                }

                // 3D Call launcher
                ThreeDButton(
                    onClick = onCallClick,
                    brandGradientColors = listOf(BrandPrimary, BrandSecondary),
                    depthColor = Color(0xFF312E81),
                    cornerRadius = 12.dp,
                    modifier = Modifier.size(width = 72.dp, height = 36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Call,
                        contentDescription = "Call Contact",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

// 5. Recent Calls row log
@Composable
fun RecentCallRow(
    log: CallHistoryEntity,
    isDark: Boolean,
    onCallClick: () -> Unit
) {
    val formatter = SimpleDateFormat("hh:mm a", Locale.getDefault())
    val dateString = formatter.format(Date(log.timestamp))

    val isIncoming = log.isIncoming
    val answered = log.wasAnswered

    val durationMin = log.durationSeconds / 60
    val durationSec = log.durationSeconds % 60
    val durStr = if (log.durationSeconds > 0) "${durationMin}m ${durationSec}s" else "No answer"

    GlassmorphicCard(
        modifier = Modifier.fillMaxWidth(),
        cornerRadius = 16.dp,
        isDarkTheme = isDark
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                // Incoming vs Outgoing icon layout
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(
                            when {
                                !isIncoming && answered -> Color(0xFF22C55E).copy(alpha = 0.15f) // Outgoing green
                                isIncoming && answered -> BrandAccent.copy(alpha = 0.15f) // Incoming cyan
                                else -> Color(0xFFEF4444).copy(alpha = 0.15f) // Missed red
                            }
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = when {
                            !isIncoming -> Icons.Default.CallMade
                            answered -> Icons.Default.CallReceived
                            else -> Icons.Default.CallMissed
                        },
                        contentDescription = null,
                        tint = when {
                            !isIncoming && answered -> Color(0xFF22C55E)
                            isIncoming && answered -> BrandAccent
                            else -> Color(0xFFEF4444)
                        },
                        modifier = Modifier.size(16.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = log.username,
                        color = if (isDark) Color.White else Color.Black,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = log.type,
                            color = BrandAccent,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Box(modifier = Modifier.size(3.dp).clip(CircleShape).background(Color.Gray))
                        Text(
                            text = durStr,
                            color = if (isDark) Color.White.copy(alpha = 0.4f) else Color.Gray,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = dateString,
                    color = if (isDark) Color.White.copy(alpha = 0.4f) else Color.Gray,
                    fontSize = 11.sp
                )

                // Quick Redial hook shape button
                IconButton(
                    onClick = onCallClick,
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.PhoneCallback,
                        contentDescription = "Callback",
                        tint = if (isDark) Color.White.copy(alpha = 0.6f) else BrandPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

// 6. Incoming call simulated push banner
@Composable
fun IncomingCallBanner(
    contact: ContactEntity,
    isDark: Boolean,
    onAccept: () -> Unit,
    onDecline: () -> Unit
) {
    // Beautiful floating dynamic push card modal
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isDark) Color(0xFF141733) else Color.White
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                border = BorderStroke(1.dp, Brush.linearGradient(listOf(BrandAccent, BrandSecondary))),
                shape = RoundedCornerShape(24.dp)
            )
            .padding(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                // Ringing icon indicator
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(BrandAccent.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.PhoneInTalk,
                        contentDescription = null,
                        tint = BrandAccent,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = "INCOMING 3D VOIP CALL",
                        color = BrandAccent,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = contact.username,
                        color = if (isDark) Color.White else Color.Black,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "E2E Secured • HD Quality",
                        color = Color.Green,
                        fontSize = 10.sp
                    )
                }
            }

            // Quick Call Accept vs Decline Action buttons side by side
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Decline (Red icon)
                IconButton(
                    onClick = onDecline,
                    colors = IconButtonDefaults.iconButtonColors(
                        containerColor = Color(0x22EF4444)
                    )
                ) {
                    Icon(
                        imageVector = Icons.Default.CallEnd,
                        contentDescription = "Decline call",
                        tint = Color(0xFFEF4444)
                    )
                }

                // Accept (Green icon)
                IconButton(
                    onClick = onAccept,
                    colors = IconButtonDefaults.iconButtonColors(
                        containerColor = Color(0x2222C55E)
                    )
                ) {
                    Icon(
                        imageVector = Icons.Default.Call,
                        contentDescription = "Accept call",
                        tint = Color(0xFF22C55E)
                    )
                }
            }
        }
    }
}
