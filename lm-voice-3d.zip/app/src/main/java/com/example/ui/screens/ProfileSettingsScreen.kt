package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.GlassmorphicCard
import com.example.ui.components.GlassmorphicTextField
import com.example.ui.components.ThreeDButton
import com.example.ui.theme.BrandAccent
import com.example.ui.theme.BrandPrimary
import com.example.ui.theme.BrandSecondary
import com.example.viewmodel.AppViewModel

@Composable
fun ProfileSettingsScreen(
    viewModel: AppViewModel,
    onNavigateBack: () -> Unit,
    onLogoutSuccess: () -> Unit
) {
    val currentUser = viewModel.currentUser ?: return
    val isDark = viewModel.isDarkTheme

    var editName by remember { mutableStateOf(currentUser.username) }
    var editPhone by remember { mutableStateOf(currentUser.phone) }
    var selectedStatus by remember { mutableStateOf(viewModel.userStatus) }

    val statusOptions = listOf("Online", "Busy", "Offline")

    // Background gradient configurations
    val backgroundBrush = if (isDark) {
        Brush.verticalGradient(listOf(Color(0xFF0A0C1D), Color(0xFF14172E)))
    } else {
        Brush.verticalGradient(listOf(Color(0xFFF2F4FC), Color(0xFFE3E5FA)))
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(backgroundBrush)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(20.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // 1. Navigation Header
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(if (isDark) Color(0x11FFFFFF) else Color(0x194F46E5))
                            .clickable { onNavigateBack() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Back",
                            tint = if (isDark) Color.White else BrandPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Text(
                        text = "Profile Settings",
                        color = if (isDark) Color.White else Color(0xFF1E1B4B),
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                // 2. Avatar Display and status card
                GlassmorphicCard(
                    modifier = Modifier.fillMaxWidth(),
                    isDarkTheme = isDark
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Large Avatar display with active neon rim
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(
                                    brush = Brush.sweepGradient(
                                        colors = listOf(BrandAccent, BrandSecondary, BrandAccent)
                                    )
                                )
                                .padding(4.dp)
                                .clip(CircleShape)
                                .background(if (isDark) Color(0xFF13152C) else Color.White),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = currentUser.username.split(" ").map { it.take(1) }.joinToString(""),
                                color = BrandAccent,
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.width(16.dp))

                        Column {
                            Text(
                                text = currentUser.username,
                                color = if (isDark) Color.White else Color.Black,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "ID: ${currentUser.lmId}",
                                color = BrandAccent,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = currentUser.emailOrPhone,
                                color = if (isDark) Color.White.copy(alpha = 0.5f) else Color.Gray,
                                fontSize = 12.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // 3. Status picker nodes
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "PRESENCE STATUS (VOIP)",
                        color = if (isDark) Color.White.copy(alpha = 0.5f) else Color.Gray,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        statusOptions.forEach { status ->
                            val isSelected = selectedStatus == status
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(
                                        if (isSelected) {
                                            if (status == "Online") Color(0xFF22C55E).copy(alpha = 0.2f)
                                            else if (status == "Busy") Color(0xFFEF4444).copy(alpha = 0.2f)
                                            else Color.Gray.copy(alpha = 0.2f)
                                        } else {
                                            if (isDark) Color(0x19FFFFFF) else Color(0xCCFFFFFF)
                                        }
                                    )
                                    .border(
                                        1.dp,
                                        if (isSelected) {
                                            if (status == "Online") Color(0xFF22C55E)
                                            else if (status == "Busy") Color(0xFFEF4444)
                                            else Color.Gray
                                        } else Color.Transparent,
                                        RoundedCornerShape(12.dp)
                                    )
                                    .clickable {
                                        selectedStatus = status
                                        viewModel.updateProfile(editName, editPhone, status)
                                    }
                                    .padding(vertical = 12.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(
                                                when (status) {
                                                    "Online" -> Color.Green
                                                    "Busy" -> Color.Red
                                                    else -> Color.Gray
                                                }
                                            )
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = status,
                                        color = if (isDark) Color.White else Color.Black,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // 4. Custom settings modifications
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "CUSTOMIZE CALL IDENTITY",
                        color = if (isDark) Color.White.copy(alpha = 0.5f) else Color.Gray,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )

                    // Profile Name
                    GlassmorphicTextField(
                        value = editName,
                        onValueChange = {
                            editName = it
                            viewModel.updateProfile(it, editPhone, selectedStatus)
                        },
                        placeholder = "Caller display name",
                        leadingIcon = Icons.Default.Edit,
                        isDarkTheme = isDark
                    )

                    // Phone customizer
                    GlassmorphicTextField(
                        value = editPhone,
                        onValueChange = {
                            editPhone = it
                            viewModel.updateProfile(editName, it, selectedStatus)
                        },
                        placeholder = "VoIP outbound display number",
                        leadingIcon = Icons.Default.Phone,
                        isDarkTheme = isDark
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Theme visual selection slider
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (isDark) Color(0x19FFFFFF) else Color(0xCCFFFFFF))
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Palette,
                            contentDescription = null,
                            tint = BrandAccent
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Premium Dark Mode",
                                color = if (isDark) Color.White else Color.Black,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "High-contrast glowing glass",
                                color = if (isDark) Color.White.copy(alpha = 0.5f) else Color.Gray,
                                fontSize = 11.sp
                            )
                        }
                    }
                    Switch(
                        checked = isDark,
                        onCheckedChange = { viewModel.isDarkTheme = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = BrandAccent,
                            checkedTrackColor = BrandPrimary,
                            uncheckedThumbColor = BrandPrimary,
                            uncheckedTrackColor = Color.LightGray
                        )
                    )
                }
            }

            // 5. Encrypted Core Footer & Log out triggering button
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Security,
                        contentDescription = null,
                        tint = Color.Gray,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Secure WebRTC 256-bit AES link active",
                        color = Color.Gray,
                        fontSize = 11.sp,
                        textAlign = TextAlign.Center
                    )
                }

                // Log out bottom button (tactile 3D red-coral style)
                ThreeDButton(
                    onClick = {
                        viewModel.logout {
                            onLogoutSuccess()
                        }
                    },
                    brandGradientColors = listOf(Color(0xFFEF4444), Color(0xFFDC2626)),
                    depthColor = Color(0xFF991B1B),
                    text = "Sign out secure connection",
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}
