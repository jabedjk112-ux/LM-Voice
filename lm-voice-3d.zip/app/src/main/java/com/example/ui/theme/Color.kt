package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand Palette
val BrandPrimary = Color(0xFF4F46E5)   // Deep Indigo Blue
val BrandSecondary = Color(0xFF7C3AED) // Rich Electric Violet
val BrandAccent = Color(0xFF06B6D4)    // Cyber Cyan

// Premium Theme Colors - Dark
val DarkBgStart = Color(0xFF090A1A)     // Cosmic Deep Navy Start
val DarkBgEnd = Color(0xFF13152B)       // Cosmic Deep Space End
val DarkGlassBody = Color(0x19FFFFFF)   // 10% translucent white
val DarkGlassBorder = Color(0x33FFFFFF) // 20% translucent white border
val CyberPurpleGlow = Color(0x1F7C3AED) // Subtle purple glow
val CyberCyanGlow = Color(0x1F06B6D4)   // Subtle cyan glow

// Premium Theme Colors - Light
val LightBgStart = Color(0xFFF1F2F9)    // Elegant pale ice blue
val LightBgEnd = Color(0xFFE2E4FA)      // Soft lilac gradient
val LightGlassBody = Color(0xCCFFFFFF)  // 80% translucent white
val LightGlassBorder = Color(0x664F46E5)// Soft tint indigo border

// Legacy Color Mappings to satisfy potential pre-compiled usages
val Purple80 = Color(0xFF818CF8)
val PurpleGrey80 = Color(0xFFA5B4FC)
val Pink80 = Color(0xFF67E8F9)

val Purple40 = Color(0xFF4F46E5)
val PurpleGrey40 = Color(0xFF7C3AED)
val Pink40 = Color(0xFF06B6D4)

