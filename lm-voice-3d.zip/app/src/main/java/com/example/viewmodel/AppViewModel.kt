package com.example.viewmodel

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlin.random.Random

@OptIn(ExperimentalCoroutinesApi::class)
class AppViewModel(
    application: Application,
    private val repository: AppRepository
) : AndroidViewModel(application) {

    // --- Authentication State ---
    var currentUser by mutableStateOf<UserSession?>(null)
        private set

    var isAuthenticating by mutableStateOf(false)
        private set

    var authError by mutableStateOf<String?>(null)
        private set

    // --- Active Contact Search ---
    var searchQuery by mutableStateOf("")
        private set

    val contacts: StateFlow<List<ContactEntity>> = snapshotFlow { searchQuery }
        .flatMapLatest { query ->
            repository.searchContacts(query)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favorites: StateFlow<List<ContactEntity>> = repository.favoriteContacts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val callLogs: StateFlow<List<CallHistoryEntity>> = repository.callHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Calling Engine State (Simulated WebRTC) ---
    var activeCallState by mutableStateOf<CallState>(CallState.Idle)
        private set

    var activeCallContact by mutableStateOf<ContactEntity?>(null)
        private set

    var callDurationSeconds by mutableStateOf(0)
        private set

    var isMuted by mutableStateOf(false)

    var isSpeakerOn by mutableStateOf(false)

    private var callTimerJob: Job? = null

    // --- App Customization Preferences ---
    var isDarkTheme by mutableStateOf(true) // Default to standard Slate Cyber-Dark
    var userStatus by mutableStateOf("Online")

    // --- Simulated Incoming Call Scheduler ---
    var incomingCallFrom by mutableStateOf<ContactEntity?>(null)
        private set

    init {
        // Prepare database with premium starter users
        viewModelScope.launch {
            repository.preseedDatabaseIfEmpty()
        }

        // Schedule an occasional simulated incoming call from a fav contact to demonstrate push/ringing (e.g. in 20 seconds)
        triggerSimulatedIncomingCallTimer()
    }

    // --- Auth Actions ---
    fun login(emailOrPhone: String, password: String, onSuccess: () -> Unit) {
        if (emailOrPhone.isBlank() || password.length < 4) {
            authError = "Invalid credentials. Password must be 4+ chars."
            return
        }

        viewModelScope.launch {
            isAuthenticating = true
            authError = null
            delay(1200) // Realistic server handshake lag

            val name = if (emailOrPhone.contains("@")) {
                emailOrPhone.substringBefore("@").replaceFirstChar { it.uppercase() }
            } else {
                "User_" + emailOrPhone.takeLast(4)
            }

            currentUser = UserSession(
                username = name,
                emailOrPhone = emailOrPhone,
                lmId = "LM-${Random.nextInt(1000, 9999)}",
                status = "Online",
                avatarSeed = name.lowercase()
            )
            isAuthenticating = false
            onSuccess()
        }
    }

    fun register(username: String, email: String, phone: String, password: String, onSuccess: () -> Unit) {
        if (username.isBlank() || email.isBlank() || phone.isBlank() || password.length < 4) {
            authError = "Please fill all fields and enter a valid password."
            return
        }

        viewModelScope.launch {
            isAuthenticating = true
            authError = null
            delay(1500) // Web registration latency

            val newLmId = "LM-${Random.nextInt(1000, 9999)}"
            currentUser = UserSession(
                username = username,
                emailOrPhone = email,
                phone = phone,
                lmId = newLmId,
                status = "Online",
                avatarSeed = username.lowercase()
            )

            // Auto-insert newly registered user to the general contacts database so we can call ourselves
            repository.insertContact(
                ContactEntity(
                    username = username,
                    phone = phone,
                    lmId = newLmId,
                    isFavorite = false,
                    status = "Online",
                    customAvatarSeed = username.lowercase()
                )
            )

            isAuthenticating = false
            onSuccess()
        }
    }

    fun logout(onSuccess: () -> Unit) {
        currentUser = null
        onSuccess()
    }

    fun updateProfile(name: String, phone: String, status: String) {
        currentUser?.let { session ->
            currentUser = session.copy(
                username = name,
                phone = phone,
                status = status
            )
            userStatus = status
        }
    }

    fun updateSearchQuery(query: String) {
        searchQuery = query
    }

    // --- Call Trigger Actions ---
    fun startOutlineCall(contact: ContactEntity) {
        if (activeCallState != CallState.Idle) return

        viewModelScope.launch {
            activeCallContact = contact
            activeCallState = CallState.Ringing(isIncoming = false)
            isMuted = false
            isSpeakerOn = false
            callDurationSeconds = 0

            // 2.5 seconds WebRTC negotiation, ICE gathering
            delay(2500)

            activeCallState = CallState.Connected
            startCallTimer()
        }
    }

    fun answerIncomingCall() {
        val contact = incomingCallFrom ?: return
        incomingCallFrom = null
        activeCallContact = contact
        activeCallState = CallState.Connected
        isMuted = false
        isSpeakerOn = false
        callDurationSeconds = 0
        startCallTimer()
    }

    fun rejectIncomingCall() {
        val contact = incomingCallFrom ?: return
        incomingCallFrom = null

        viewModelScope.launch {
            // Save missed call log
            repository.addCallRecord(
                CallHistoryEntity(
                    username = contact.username,
                    phone = contact.phone,
                    lmId = contact.lmId,
                    durationSeconds = 0,
                    isIncoming = true,
                    wasAnswered = false,
                    type = "Missed HD Call"
                )
            )
        }
    }

    fun endCall() {
        val contact = activeCallContact ?: return
        val duration = callDurationSeconds

        callTimerJob?.cancel()
        callTimerJob = null
        activeCallState = CallState.Idle

        viewModelScope.launch {
            // Log completed call
            repository.addCallRecord(
                CallHistoryEntity(
                    username = contact.username,
                    phone = contact.phone,
                    lmId = contact.lmId,
                    durationSeconds = duration,
                    isIncoming = false, // Outgoing call ended
                    wasAnswered = true,
                    type = "Secure WebRTC 3D"
                )
            )
            activeCallContact = null
        }
    }

    private fun startCallTimer() {
        callTimerJob?.cancel()
        callTimerJob = viewModelScope.launch {
            while (activeCallState is CallState.Connected) {
                delay(1000)
                callDurationSeconds++
            }
        }
    }

    // Toggle contact favorites directly in DB
    fun toggleFavorite(contact: ContactEntity) {
        viewModelScope.launch {
            repository.updateContact(contact.copy(isFavorite = !contact.isFavorite))
        }
    }

    fun clearCallHistory() {
        viewModelScope.launch {
            repository.clearCallHistory()
        }
    }

    // Trigger standard call from log history quickly
    fun callFromHistory(log: CallHistoryEntity) {
        val mappedContact = ContactEntity(
            username = log.username,
            phone = log.phone,
            lmId = log.lmId,
            customAvatarSeed = log.username.lowercase()
        )
        startOutlineCall(mappedContact)
    }

    // Simulate occasional incoming calls trigger
    private fun triggerSimulatedIncomingCallTimer() {
        viewModelScope.launch {
            // Wait 25 seconds of activity to show a simulated incoming call.
            // This displays as an incoming WebRTC invitation modal at the top or full screen,
            // perfect for demonstrator review.
            delay(25000)
            if (activeCallState == CallState.Idle && incomingCallFrom == null) {
                // Pick a contact (prefer Sophia Lee or Emma Watson)
                incomingCallFrom = ContactEntity(
                    username = "Sophia Lee",
                    phone = "+1 415 889 0293",
                    lmId = "LM-9240",
                    isFavorite = true,
                    status = "Online",
                    customAvatarSeed = "sophia"
                )
            }
        }
    }

    fun triggerImmediateSimulatedIncomingCall() {
        viewModelScope.launch {
            if (activeCallState == CallState.Idle) {
                incomingCallFrom = ContactEntity(
                    username = "Emma Watson",
                    phone = "+1 212 555 0199",
                    lmId = "LM-3391",
                    isFavorite = true,
                    status = "Online",
                    customAvatarSeed = "emma"
                )
            }
        }
    }
}

// Session representations
data class UserSession(
    val username: String,
    val emailOrPhone: String,
    val phone: String = "+1 555 120 4482",
    val lmId: String,
    val status: String = "Online",
    val avatarSeed: String = "default"
)

// Standard state machine for high precision calls
sealed class CallState {
    object Idle : CallState()
    data class Ringing(val isIncoming: Boolean) : CallState()
    object Connected : CallState()
}

// ViewModel Factory to coordinate Room
class AppViewModelFactory(
    private val application: Application,
    private val repository: AppRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(AppViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return AppViewModel(application, repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
